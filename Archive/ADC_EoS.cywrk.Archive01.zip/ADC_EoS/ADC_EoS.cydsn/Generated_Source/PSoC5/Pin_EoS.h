/*******************************************************************************
* File Name: Pin_EoS.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Pin_EoS_H) /* Pins Pin_EoS_H */
#define CY_PINS_Pin_EoS_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Pin_EoS_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Pin_EoS__PORT == 15 && ((Pin_EoS__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    Pin_EoS_Write(uint8 value) ;
void    Pin_EoS_SetDriveMode(uint8 mode) ;
uint8   Pin_EoS_ReadDataReg(void) ;
uint8   Pin_EoS_Read(void) ;
uint8   Pin_EoS_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Pin_EoS_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Pin_EoS_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Pin_EoS_DM_RES_UP          PIN_DM_RES_UP
#define Pin_EoS_DM_RES_DWN         PIN_DM_RES_DWN
#define Pin_EoS_DM_OD_LO           PIN_DM_OD_LO
#define Pin_EoS_DM_OD_HI           PIN_DM_OD_HI
#define Pin_EoS_DM_STRONG          PIN_DM_STRONG
#define Pin_EoS_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Pin_EoS_MASK               Pin_EoS__MASK
#define Pin_EoS_SHIFT              Pin_EoS__SHIFT
#define Pin_EoS_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Pin_EoS_PS                     (* (reg8 *) Pin_EoS__PS)
/* Data Register */
#define Pin_EoS_DR                     (* (reg8 *) Pin_EoS__DR)
/* Port Number */
#define Pin_EoS_PRT_NUM                (* (reg8 *) Pin_EoS__PRT) 
/* Connect to Analog Globals */                                                  
#define Pin_EoS_AG                     (* (reg8 *) Pin_EoS__AG)                       
/* Analog MUX bux enable */
#define Pin_EoS_AMUX                   (* (reg8 *) Pin_EoS__AMUX) 
/* Bidirectional Enable */                                                        
#define Pin_EoS_BIE                    (* (reg8 *) Pin_EoS__BIE)
/* Bit-mask for Aliased Register Access */
#define Pin_EoS_BIT_MASK               (* (reg8 *) Pin_EoS__BIT_MASK)
/* Bypass Enable */
#define Pin_EoS_BYP                    (* (reg8 *) Pin_EoS__BYP)
/* Port wide control signals */                                                   
#define Pin_EoS_CTL                    (* (reg8 *) Pin_EoS__CTL)
/* Drive Modes */
#define Pin_EoS_DM0                    (* (reg8 *) Pin_EoS__DM0) 
#define Pin_EoS_DM1                    (* (reg8 *) Pin_EoS__DM1)
#define Pin_EoS_DM2                    (* (reg8 *) Pin_EoS__DM2) 
/* Input Buffer Disable Override */
#define Pin_EoS_INP_DIS                (* (reg8 *) Pin_EoS__INP_DIS)
/* LCD Common or Segment Drive */
#define Pin_EoS_LCD_COM_SEG            (* (reg8 *) Pin_EoS__LCD_COM_SEG)
/* Enable Segment LCD */
#define Pin_EoS_LCD_EN                 (* (reg8 *) Pin_EoS__LCD_EN)
/* Slew Rate Control */
#define Pin_EoS_SLW                    (* (reg8 *) Pin_EoS__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Pin_EoS_PRTDSI__CAPS_SEL       (* (reg8 *) Pin_EoS__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Pin_EoS_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Pin_EoS__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Pin_EoS_PRTDSI__OE_SEL0        (* (reg8 *) Pin_EoS__PRTDSI__OE_SEL0) 
#define Pin_EoS_PRTDSI__OE_SEL1        (* (reg8 *) Pin_EoS__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Pin_EoS_PRTDSI__OUT_SEL0       (* (reg8 *) Pin_EoS__PRTDSI__OUT_SEL0) 
#define Pin_EoS_PRTDSI__OUT_SEL1       (* (reg8 *) Pin_EoS__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Pin_EoS_PRTDSI__SYNC_OUT       (* (reg8 *) Pin_EoS__PRTDSI__SYNC_OUT) 


#if defined(Pin_EoS__INTSTAT)  /* Interrupt Registers */

    #define Pin_EoS_INTSTAT                (* (reg8 *) Pin_EoS__INTSTAT)
    #define Pin_EoS_SNAP                   (* (reg8 *) Pin_EoS__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Pin_EoS_H */


/* [] END OF FILE */
